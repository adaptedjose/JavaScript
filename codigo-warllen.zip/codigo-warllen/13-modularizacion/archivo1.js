export function suma(a, b) {
    return a + b;
}

export const PI = 3.1415296;