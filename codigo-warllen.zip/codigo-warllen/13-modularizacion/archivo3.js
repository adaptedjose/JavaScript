import * as arch from './archivo1.js';

console.log(arch.suma(4,5));
console.log(arch.PI);