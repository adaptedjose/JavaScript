import  {suma, PI} from './archivo1.js'

console.log(suma(1,2));
console.log(PI);